/**Filename: IDsorter
@version: 1.0;
@author: Mwiche Dina Nachilongo 202208650
Program to: display creation of selection sort algorithm
To compile: javac IDsorter.java
To execute: java ID.sorter */

package Lab9;

