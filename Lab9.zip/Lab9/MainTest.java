/**Filename: MainTest
@version: 1.0;
@author: Mwiche Dina Nachilongo 202208650
Program to: Implement creation of selection sort algorithm
To compile: javac MainTest.java
To execute: java IDsorter MainTest */

package Lab9;

public class IDsorter{
    public static int selectionSorter (int [] studentIDs){
        for (int i = 0; i< studentIDs.length -1; i++){ // pick position i 
            int minIndex = i;

            // Scan sub-array to find global minimum
            for (int a = i + 1; a < studentIDs.length ; a++){
                do{
                  minIndex = studentIDs [a];
                }
                    while (( a < studentIDs.length) &&(studentIDs [a] < studentIDs [i]));
            // Swap places that min at index i
            int temp = studentIDs [a];
            studentIDs[a] = studentIDs [i];
            studentIDs [i] = temp;
                
            }
        }
    }
    public static int linearSearch (int [] studentIDs, int target){
        for (int i= 0; i< studentIDs.length; i++){
            if(studentIDs [i]== target){
                return i; //found
            }
        }
        return -1; //not found


    }
}


public class TempArray{
    public static void main (String [] args){
        int [] temperatureRecord = new int [5]; // Declare array of 5 integers
        temperatureRecord [0] = 38;
        temperatureRecord[1] = 40;
            temperatureRecord [2] = 35;
        temperatureRecord [3] = 29;
        temperatureRecord [4] = 19;
    }
}





public class MainTest{
    public static void main ( String [] args){

int [] studentIDs = new int [5]; // Declare array of 5 integers
        studentIDs [0] = 0;
        studentIDs[1] = 8;
        studentIDs [2] = 6;
        studentIDs [3] = 5;
        studentIDs [4] = 0;

//compute difference between maximum and mininmum values
      int difference =   studentIDs [4] - studentIDs [0];
// print original array
System.out.println("Original array: " + Arrays.toString(studentIDs));

//print sorted array
 IDsorter.selectionSorter(studentIDs);
System.out.println("Sorted array:" + Arrays.toString(studentIDs));

//print difference
System.out.println("The difference computed is" +difference);

//print last digit of id
int index = IDsorter.linearSearch(studentIDs, 0);
System.out.println("The last digit of the ID is" +index);

//print temperature records
IDsorter.selectionSorter(temperatureRecord);
System.out.println("The sorted temperatures are" +Arrays.toString(temperatureRecord));

    }
}