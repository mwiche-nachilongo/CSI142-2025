/**Filename: SorterArray
@version: 1.0;
@author: Mwiche Dina Nachilongo 202208650dir
Program to: Declare finite array to to be sorted
To compile: javac SorterArray.java
To execute: java SorterArray */

package Lab9;

}
}