/**Filename: SelectionSort
@version: 1.0;
@author: Mwiche Dina Nachilongo 202208650
Program to: Implement creation of selection sort class
To compile: javac SelectionSort.java
To execute: java SelectionSort */

package Lab9;

public class SeclectionSort{
    protected String location;
    protected int temperature;
    public SelectionSort( String location, int temperature){
        this.location= location;
        this.temperature = temperature;
    }
}
