/**Filename: Bank.java
 * @version: 1.0
 * @author: Not specified (Code provided)
 * To compile: javac *.java
 * To run composition test: java BankTest 
 * To run inheritance test: java SavingTest
 */

import java.util.ArrayList;
 public class Bank{
    
 }