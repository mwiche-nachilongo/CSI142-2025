/**Filename: BagApp.java
 * @author: Mwiche Dina Nachilongo 202208650
 * @version: 1.0
 * lab number: 297
 * Description: Base class used  to illustrate constructor chaining
 * To compile: javac BagApp.java
 * To execute: java BagApp
 */

 import com.StudentBelongings.Contents
 
public class BagApp {
    public static void main (String [] args){
        
    }


}